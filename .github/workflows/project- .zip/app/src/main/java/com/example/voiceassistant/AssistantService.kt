package com.example.voiceassistant

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.sqrt

class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_TOGGLE = "toggle_game_mode"
        const val CHANNEL = "assistant"
        const val MAX_HISTORY = 20
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
        const val SR = 16000
        val YES = setOf("हाँ", "हां", "हा", "हाँजी", "yes", "yeah", "ok", "okay", "ठीक", "जी",
            "भेज", "भेजो", "करो", "कर")
        val NO = setOf("नहीं", "नही", "no", "cancel", "रद्द", "मत", "रुको", "stop")
    }

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("mem", MODE_PRIVATE) }
    private val runner by lazy { ActionRunner(this) }
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = true
    @Volatile private var paused = false   // गेम मोड
    @Volatile private var busy = false     // सोच/बोल रहा हो तो माइक की आवाज़ अनदेखी
    @Volatile private var working = false  // फ़ोन के काम चल रहे हैं
    @Volatile private var blockedUntil = 0L // Gemini की लिमिट लगने पर इस समय तक कॉल नहीं
    private var status = "सुन रहा हूँ 🎤"

    private var pending: List<JSONObject>? = null   // हाँ/नहीं का इंतज़ार करता काम
    private var pendingAt = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Assistant", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dhakad:listen").apply { acquire() }

        tts = TextToSpeech(this, this)
        startAudioLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TOGGLE) {
            paused = !paused
            setStatus(if (paused) "गेम मोड: रुका हुआ" else "सुन रहा हूँ 🎤")
        }
        return START_STICKY
    }

    // ---------- नोटिफ़िकेशन ----------
    private fun buildNotification(): Notification {
        val pi = PendingIntent.getService(
            this, 0,
            Intent(this, AssistantService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause),
            if (paused) "सुनना शुरू करें" else "गेम मोड (रोकें)", pi).build()
        return Notification.Builder(this, CHANNEL)
            .setContentTitle(if (paused) "गेम मोड: असिस्टेंट रुका है" else "धाकड़ असिस्टेंट चालू है")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(action)
            .setOngoing(true)
            .build()
    }

    private fun setStatus(s: String) {
        status = s
        handler.post {
            getSystemService(NotificationManager::class.java).notify(1, buildNotification())
        }
    }

    // ---------- आवाज़ (TTS) ----------
    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) {
            setStatus("बोलने वाला इंजन नहीं चला: Google Text-to-speech इंस्टॉल करें")
            return
        }
        val r = tts.setLanguage(Locale("hi", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            tts.setLanguage(Locale.getDefault())
        tts.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { listenSoon() }
            override fun onError(id: String?) { listenSoon() }
        })
        ttsReady = true
    }

    private fun say(msg: String, flush: Boolean = true) {
        handler.post {
            busy = true
            val mode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            if (ttsReady && tts.speak(msg, mode, null, "u" + System.nanoTime()) == TextToSpeech.SUCCESS)
                return@post
            listenSoon()
        }
    }

    /** बोलना/काम ख़त्म होने के थोड़ी देर बाद फिर सुनना शुरू (अपनी ही आवाज़ न पकड़े) */
    private fun listenSoon() {
        handler.postDelayed({
            if (working || (ttsReady && tts.isSpeaking)) listenSoon()
            else {
                busy = false
                setStatus(if (paused) "गेम मोड: रुका हुआ" else "सुन रहा हूँ 🎤")
            }
        }, 700)
    }

    // ---------- माइक सुनना (VAD) ----------
    @SuppressLint("MissingPermission")
    private fun startAudioLoop() {
        thread(name = "audio-loop") {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            val minBuf = AudioRecord.getMinBufferSize(
                SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, SR * 2))
            } catch (e: Exception) {
                setStatus("माइक नहीं खुला: परमिशन चेक करें"); return@thread
            }
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                setStatus("माइक की परमिशन/एक्सेस नहीं मिली"); return@thread
            }

            val chunk = ShortArray(1600)           // 100 ms
            val buf = ByteArrayOutputStream()
            val preroll = ArrayDeque<ShortArray>()
            var recording = false
            var inSpeech = false
            var loudRun = 0
            var loudTotal = 0
            var quiet = 0
            var noise = 300.0

            try {
                while (running) {
                    if (paused) {                   // गेम मोड: माइक पूरी तरह छोड़ दो
                        if (recording) { rec.stop(); recording = false }
                        inSpeech = false; buf.reset(); preroll.clear(); loudRun = 0
                        Thread.sleep(300); continue
                    }
                    if (!recording) { rec.startRecording(); recording = true }

                    val n = rec.read(chunk, 0, chunk.size)
                    if (n < 0) {                    // माइक किसी और ने ले लिया, फिर कोशिश
                        try { rec.stop() } catch (_: Exception) {}
                        recording = false; Thread.sleep(500); continue
                    }
                    if (n == 0) { Thread.sleep(50); continue }
                    if (busy) {                     // सोच/बोल रहा है, आवाज़ अनदेखी
                        inSpeech = false; buf.reset(); preroll.clear(); loudRun = 0
                        continue
                    }

                    var sum = 0.0
                    for (i in 0 until n) sum += chunk[i].toDouble() * chunk[i]
                    val rms = sqrt(sum / n)
                    val loud = rms > maxOf(600.0, noise * 3.5)

                    if (!inSpeech) {
                        if (!loud) noise = noise * 0.97 + rms * 0.03
                        preroll.addLast(chunk.copyOf(n))
                        if (preroll.size > 4) preroll.removeFirst()
                        loudRun = if (loud) loudRun + 1 else 0
                        if (loudRun >= 2) {         // बोलना शुरू हुआ
                            inSpeech = true; quiet = 0; loudTotal = loudRun
                            for (c in preroll) writeShorts(buf, c)
                            preroll.clear()
                        }
                    } else {
                        writeShorts(buf, chunk.copyOf(n))
                        if (loud) { quiet = 0; loudTotal++ } else quiet++
                        if (quiet >= 10 || buf.size() > SR * 2 * 20) {   // 1 सेकंड चुप्पी / 20 सेकंड पूरे
                            val pcm = buf.toByteArray()
                            buf.reset(); inSpeech = false; loudRun = 0
                            if (loudTotal >= 4 && System.currentTimeMillis() >= blockedUntil) {   // छोटी आवाज़ और लिमिट के समय अनदेखी
                                busy = true
                                setStatus("सोच रहा हूँ…")
                                thread(priority = Thread.MIN_PRIORITY) { processAudio(pcm) }
                            }
                            loudTotal = 0
                        }
                    }
                }
            } catch (e: Exception) {
                setStatus("माइक एरर: ${e.javaClass.simpleName}")
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
            }
        }
    }

    private fun writeShorts(out: ByteArrayOutputStream, s: ShortArray) {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in s) bb.putShort(v)
        out.write(bb.array())
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16)
        h.putShort(1); h.putShort(1); h.putInt(SR); h.putInt(SR * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(pcm.size)
        return h.array() + pcm
    }

    // ---------- याददाश्त ----------
    private fun turn(role: String, text: String) = JSONObject().put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun loadHistory(): JSONArray =
        try { JSONArray(prefs.getString("h", "[]")) } catch (e: Exception) { JSONArray() }

    private fun saveTurn(user: String, model: String) {
        val hist = loadHistory()
        hist.put(turn("user", user)).put(turn("model", model))
        val trimmed = JSONArray()
        for (i in maxOf(0, hist.length() - MAX_HISTORY) until hist.length()) trimmed.put(hist.get(i))
        prefs.edit().putString("h", trimmed.toString()).apply()
    }

    // ---------- Gemini ----------
    private fun callGemini(url: String, key: String, body: JSONObject): Pair<Int, String> {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
            doOutput = true; connectTimeout = 15000; readTimeout = 45000
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return Pair(code, stream?.bufferedReader()?.readText() ?: "")
    }

    private fun apiMessage(raw: String): String =
        try { JSONObject(raw).getJSONObject("error").getString("message").take(120) }
        catch (e: Exception) { "" }

    private fun systemPrompt(city: String): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.ENGLISH).format(Date())
        val bat = try {
            getSystemService(BatteryManager::class.java)
                .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) { -1 }
        val a11y = if (PhoneControlService.instance != null) "चालू है" else "बंद है"
        return """
तुम 'धाकड़ असिस्टेंट' हो, एक हिंदी वॉइस असिस्टेंट, जिसे धाकड़ ने बनाया है।
संदर्भ: अभी का समय $now। फ़ोन की बैटरी $bat%। यूज़र का शहर: ${city.ifEmpty { "पता नहीं" }}। एक्सेसिबिलिटी $a11y।
मौसम, खबर, स्कोर, भाव जैसी लाइव जानकारी के लिए Google Search इस्तेमाल करो और छोटा, सटीक जवाब दो।

यूज़र की आवाज़ ऑडियो में आती है। जवाब का फ़ॉर्मेट सख़्ती से यह रखो:
1) पहली लाइन: 'सुना: ' के बाद ऑडियो में जो बोला गया उसका सही टेक्स्ट।
2) फिर यूज़र की भाषा में 1-3 छोटे वाक्यों का जवाब, बिना markdown के। अगर कोई काम कर रहे हो तो बस बताओ कि क्या कर रहे हो।
3) अगर ऑडियो में कोई साफ़ इंसानी बोली नहीं है (शोर, खामोशी, खटपट, टीवी की पृष्ठभूमि), तो पूरे जवाब में सिर्फ़ NONE लिखो।

फ़ोन से कुछ करवाने के लिए जवाब के बाद, हर काम की अलग लाइन में, ऐसे लिखो (सिर्फ़ तब, जब यूज़र ने साफ़ कहा हो):
ACTION: {"type":"alarm","hour":6,"minute":30,"label":"उठना"}   (hour 24 घंटे में, सुबह/शाम का ध्यान रखो)
ACTION: {"type":"timer","seconds":300}
ACTION: {"type":"call","to":"राहुल","to_en":"Rahul"}   (to: नाम या नंबर जैसा यूज़र ने बोला, to_en: वही नाम रोमन अक्षरों में)
ACTION: {"type":"sms","to":"राहुल","to_en":"Rahul","text":"संदेश"}
ACTION: {"type":"whatsapp","to":"राहुल","to_en":"Rahul","text":"संदेश"}
ACTION: {"type":"contact","to":"राहुल","to_en":"Rahul"}   (किसी का नंबर बताने के लिए)
ACTION: {"type":"play_music","query":"गाने या कलाकार का नाम"}
ACTION: {"type":"media","cmd":"pause"}   (pause, play, next, previous, stop)
ACTION: {"type":"open_app","name":"YouTube"}   (ऐप का नाम अंग्रेज़ी में)
ACTION: {"type":"flashlight","on":true}
ACTION: {"type":"volume","dir":"up"}   (up, down, mute, max) या {"type":"volume","level":40}
ACTION: {"type":"maps","query":"जगह का नाम"}
ACTION: {"type":"settings","page":"wifi"}   (wifi, bluetooth, airplane, location, display, sound, battery)
ACTION: {"type":"calendar","days":1}   (कैलेंडर के कार्यक्रम पढ़ना)
ACTION: {"type":"notifications"}   (हाल के नोटिफ़िकेशन पढ़ना)
ACTION: {"type":"navigate","where":"back"}   (back, home, recents, notifications, quick_settings, lock, screenshot)
ACTION: {"type":"click","text":"स्क्रीन पर दिखता शब्द"}
ACTION: {"type":"scroll","dir":"down"}   (down या up)
ACTION: {"type":"type","text":"लिखने वाला टेक्स्ट"}
ACTION: {"type":"forget"}   (पुरानी बातचीत भूलना)
वाई-फ़ाई या ब्लूटूथ चालू-बंद करने के लिए पहले navigate quick_settings, फिर click में उसका नाम (Wi-Fi या Bluetooth) दो।
नाम, नंबर या मैसेज कभी खुद मत गढ़ो। मैसेज का टेक्स्ट यूज़र के बोले शब्दों में रखो।
पिछली बातचीत याद रखो।
""".trimIndent()
    }

    private fun processAudio(pcm: ByteArray) {
        var heard = ""
        var reply = ""
        val actions = ArrayList<JSONObject>()
        try {
            val cfg = getSharedPreferences("settings", MODE_PRIVATE)
            val key = cfg.getString("api_key", "")?.trim().orEmpty()
            if (key.isEmpty()) { say("पहले ऐप की सेटिंग में API key डालें"); return }
            val model = cfg.getString("model", DEFAULT_MODEL)?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }
            val city = cfg.getString("city", "")?.trim().orEmpty()
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

            val hist = loadHistory()
            val contents = JSONArray()
            for (i in 0 until hist.length()) contents.put(hist.getJSONObject(i))
            contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(
                JSONObject().put("inline_data", JSONObject()
                    .put("mime_type", "audio/wav")
                    .put("data", Base64.encodeToString(wav(pcm), Base64.NO_WRAP))))))

            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", systemPrompt(city)))))
                .put("contents", contents)
            if (cfg.getBoolean("use_search", true))
                body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))

            var (code, raw) = callGemini(url, key, body)
            if ((code == 400 || code == 429) && body.has("tools")) {   // सर्च की लिमिट/दिक्कत हो तो उसके बिना कोशिश
                body.remove("tools")
                val r = callGemini(url, key, body)
                code = r.first; raw = r.second
            }
            if (code == 429) {                       // थोड़ा रुककर एक बार और
                Thread.sleep(3000)
                val r = callGemini(url, key, body)
                code = r.first; raw = r.second
            }
            if (code !in 200..299) {
                setStatus("Gemini एरर $code: " + apiMessage(raw))
                if (code == 429) {
                    blockedUntil = System.currentTimeMillis() + 60_000
                    say("Gemini की लिमिट पूरी हो गई है। एक मिनट रुककर बोलिए। बार-बार हो तो AI Studio में कोटा देखें।")
                } else say("जवाब नहीं मिल पाया, एरर कोड $code")
                return
            }

            val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            val text = sb.toString().trim()

            if (text.isEmpty() || text.startsWith("NONE")) { listenSoon(); return }

            val lines = text.lines()
            var idx = 0
            if (lines.first().trim().startsWith("सुना:")) {
                heard = lines.first().substringAfter("सुना:").trim(); idx = 1
            }
            val replyLines = ArrayList<String>()
            for (l in lines.drop(idx)) {
                val t = l.trim()
                when {
                    t.startsWith("ACTION:") -> try {
                        actions.add(JSONObject(t.removePrefix("ACTION:").trim()))
                    } catch (_: Exception) { }
                    t.startsWith("```") || t.isEmpty() -> {}
                    else -> replyLines.add(t)
                }
            }
            reply = replyLines.joinToString(" ")
        } catch (e: Exception) {
            setStatus("एरर: ${e.javaClass.simpleName}")
            say("जवाब नहीं मिल पाया, इंटरनेट चेक करें")
            return
        }
        handler.post { route(heard, reply, actions) }
    }

    // ---------- जवाब + काम ----------
    private fun route(heard: String, reply: String, actions: List<JSONObject>) {
        if (heard.isNotEmpty()) setStatus("सुना: $heard")
        val h = heard.lowercase()
        val tokens = h.split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }

        // पहले पूछे गए काम (कॉल/SMS/व्हाट्सऐप) की हाँ/नहीं
        val p = pending
        if (p != null) {
            pending = null
            if (System.currentTimeMillis() - pendingAt < 30_000) {
                if (tokens.any { it in NO }) { say("ठीक है, रद्द किया"); return }
                if (tokens.any { it in YES }) { execute(p, null); return }
            }
        }

        if (actions.any { it.optString("type") == "forget" } ||
            "भूल जाओ" in h || "याददाश्त मिटाओ" in h) {
            prefs.edit().remove("h").apply()
            say("सब कुछ भूल गया"); return
        }

        saveTurn(heard.ifEmpty { "(आवाज़)" }, reply.ifEmpty { "(काम किया)" })

        val ask = actions.filter { runner.needsConfirm(it) }
        val now = actions.filter { !runner.needsConfirm(it) }
        if (ask.isNotEmpty()) {                       // सुरक्षा: भेजने/कॉल से पहले पूछो
            pending = ask; pendingAt = System.currentTimeMillis()
            if (now.isNotEmpty()) execute(now, null)
            say(runner.describe(ask[0]), flush = now.isEmpty())
            return
        }
        execute(now, reply)
    }

    private fun execute(list: List<JSONObject>, reply: String?) {
        if (!reply.isNullOrEmpty()) say(reply)
        if (list.isEmpty()) {
            if (reply.isNullOrEmpty()) listenSoon()
            return
        }
        working = true
        thread(priority = Thread.MIN_PRIORITY) {
            val results = ArrayList<String>()
            for (a in list) {
                runner.run(a)?.let { results.add(it) }
                Thread.sleep(700)
            }
            if (results.isNotEmpty()) say(results.joinToString(". "), flush = false)
            else if (reply.isNullOrEmpty()) say("हो गया", flush = false)
            working = false
            handler.post { listenSoon() }
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { tts.shutdown() } catch (_: Exception) {}
        try { wakeLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
